# -*- coding: utf-8 -*-
"""
Created on Sun Sep 27 15:13:16 2020

@author: Ankit Bhatia 8884733055
"""
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV
import pandas as pd
import numpy as np
import seaborn as sns
import sklearn
import matplotlib.pyplot as plt
from imblearn.over_sampling import RandomOverSampler
from collections import Counter
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVR
from sklearn.svm import SVC
from sklearn.svm import OneClassSVM
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import BernoulliNB
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.model_selection import cross_val_score

from sklearn.model_selection import train_test_split
import pickle
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score

#Reading Train Data set
df=pd.read_csv('Dataset.txt', sep='\t')
#Setting Index
df.set_index('Index', inplace = True)

print("Info of train dataset:")
print(df.info())
print("Description of train dataset:")
print(df.describe())
#saving train data in txt and csv format
df.to_csv('TrainDataset.txt', sep='\t')
df.to_csv('TrainDataset.csv')

#-----Exploratory Data analysis-------
print("-----Exploratory Data analysis-------")
df.hist()


#----Feature Enginerring--------
print("----Feature Enginerring--------")
#check for any null values
print("Data set has null values: ",df.isnull().values.any())


#Checking Balanced or imbalanced dataset
LABELS = ["0", "1"]
count_classes = pd.value_counts(df['C'], sort = True)
count_classes.plot(kind = 'bar', rot=0)
plt.title("Checking Balanced or imbalanced dataset")
plt.xticks(range(2), LABELS)
plt.xlabel("Class")
plt.ylabel("Frequency")

#Verifying balanced or imbalanced dataset
Yes = df[df['C']==1]
No = df[df['C']==0]
print("rows and columns of 1:", Yes.shape)
print("rows and columns of 0:",No.shape)
if(Yes.shape==No.shape):
    print("-------Dataset is balanced-----")
    
else:
    print("-------Dataset is imbalanced-----")

#changing date time format of F15 & F16 features.. fetching only year
df['F15'] = pd.DatetimeIndex(df['F15']).year
df['F16'] = pd.DatetimeIndex(df['F16']).year

#Detecting outliers:
print("-------Outliers detection for KNN Model------")
i = ['F1','F2','F3','F4','F5','F6','F7','F8','F9','F11','F12','F13','F14','F15','F16','F17','F18','F19','F20','F21','F22']
for x in i:
   
    df[x] = (df[i] - df[i].mean() ) / df[i].std()
    
    df_outliers = df[(df[x]<-3) & (df[x]>3)]
print("outliers:" ,df_outliers)
print("No outliers detected: df_outliers is empty")


#get correlations of each features in dataset
print("correlations of each features in dataset")
corrmat = df.corr()
top_corr_features = corrmat.index
print(top_corr_features)
plt.figure(figsize=(20,20))
#plot heat map
sns.heatmap(df[top_corr_features].corr(),annot=True,cmap="RdYlGn")
sns.heatmap(corrmat,annot=True)
print("Features are not correlated much.. as the max correlation between features is .65")

#Defining Input and output
print("X is input")
print("y is output")
X= df.drop(["C"], axis=1)
y= df.C


#Data is imbalanced - using random over sampler- over sampling technique
#Tried undersampling as well. but accuracy was less
print("-----------Oversampling to balance the data---------")
os =  RandomOverSampler()
X_resOs,y_resOs =os.fit_sample(X,y)

print('Original dataset shape {}'.format(Counter(y)))
print('Resampled dataset shape {}'.format(Counter(y_resOs)))

print("Dataset is balanced now")

#---Feature Selection----
# configure to select all features
print("---Feature Selection----")
bestFeatures = SelectKBest(score_func=f_classif, k=22)
# learn relationship from training data
fit1=bestFeatures.fit(X_resOs,y_resOs)
dfscores = pd.DataFrame(fit1.scores_)
dfcolumns = pd.DataFrame(X.columns)
#concat two dataframes for better visualization 
featureScores = pd.concat([dfcolumns,dfscores],axis=1)
featureScores.columns = ['Specs','Score']
print("Score of all the features: ")
print(featureScores.nlargest(22,'Score'))
#As the scoring is almost equal for all the features except F10, so selecting all the features, not dropping any feature"
#selecting features


#------Feature Scaling for train dataset------
 

feature_scale=[feature for feature in X.columns ]
scaler=MinMaxScaler()
scaler.fit(X_resOs[feature_scale])
data = pd.DataFrame(scaler.transform(X_resOs[feature_scale]), columns=feature_scale)
         
      


print("----KNN Model-----------")
#Splitting train data into train and test

X1_train, X1_test, y1_train, y1_test = train_test_split(data,y_resOs,test_size=0.3) 



#Using KNN model
#using Cross Validation
knnclassifier = KNeighborsClassifier(n_neighbors = 3)
cvKnnclassifier=cross_val_score(knnclassifier, data,y_resOs, cv=10, scoring ='accuracy').mean()

#fitting the data
knnclassifier.fit(X1_train, y1_train)
# predicting the output
y_TrainPredict =knnclassifier.predict(X1_test)
print("Accuracy of train dataset: ",cvKnnclassifier)




#dumping the model for further use
pickle.dump(knnclassifier,open('data.pkl','wb'))


#Reading test Dataset
dfTest=pd.read_csv('Dataset_test.txt', sep='\t')
dfTestOriginal=pd.read_csv('Dataset_test.txt', sep='\t')
#Setting Index
dfTest.set_index('Index', inplace = True)

#changing date time format of F15 & F16 features.. fetching only year
dfTest['F15'] = pd.DatetimeIndex(dfTest['F15']).year
dfTest['F16'] = pd.DatetimeIndex(dfTest['F16']).year

#------Feature Scaling for test data------
feature_scale_est=[featureTest for featureTest in dfTest.columns ]
scaler=MinMaxScaler()
scaler.fit(dfTest[feature_scale])
Testdata = pd.DataFrame(scaler.transform(dfTest[feature_scale]), columns=feature_scale)

      
#predicting output for test data
y_Testpredict= knnclassifier.predict(Testdata)
#print(y_Testpredict)
#addinfPredicted row in testDataset
dfTestOriginal['Predicted_Output']= y_Testpredict;

#saving test data+prediction in txt and csv format
dfTestOriginal.to_csv('TestDataset.txt', sep='\t')
dfTestOriginal.to_csv('TestDataset.csv')